package ejercicio1;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.InetAddress;
import java.net.MulticastSocket;

public class Cliente_chat extends JFrame implements ActionListener,Runnable {


    //Declaramos los datos del socket
    static MulticastSocket multisocketcliente = null;
    static byte[] buffer = new byte[1024];
    static InetAddress grupo = null;
    static int puerto = 6000;

    //Declaramos los elementos que vamos a mostrar en la interfaz
    static JTextArea textarea_chat;
    JButton enviar = new JButton("Enviar");
    JButton salir = new JButton("Salir");
    boolean repetir = true;
    String nombre;

    public Cliente_chat(String nom) {
        //Inicializamos y añadimos a la interfaz los elementos
        super("  CHAT UDP ~~~ Alias: " + nom);
        setLayout(null);
        this.nombre = nom;
        textarea_chat = new JTextArea();

        //declaramos los elementos de la interfaz
        JScrollPane chatpane = new JScrollPane(textarea_chat);
        chatpane.setBounds(10, 10, 300, 100);
        add(chatpane);
        salir.setBounds(320, 10, 100, 30);
        add(salir);

        textarea_chat.setEditable(false);
        enviar.addActionListener(this);
        salir.addActionListener(this);
        setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
    }

    public static void main(String[] args) throws IOException {
        //declaramos en la ventana el nombre con el que entramos al chat
        String alias = JOptionPane.showInputDialog("Introduce tu alias:");

        //Creamos el socket multicast con los datos declarados
        multisocketcliente = new MulticastSocket(puerto);
        grupo = InetAddress.getByName("225.0.0.1");

        //Nos unimos al grupo
        multisocketcliente.joinGroup(grupo);
        //Notificamos la entrada al chat
        String mensaje_inicio = "\n *** El usuario " + alias + " entra al chat ***";
        DatagramPacket inicioChat = new DatagramPacket(mensaje_inicio.getBytes(),mensaje_inicio.length(),grupo,puerto);
        multisocketcliente.send(inicioChat);

        if (!alias.trim().equals("")){
            //Mostramos la ventana
            Cliente_chat cliente = new Cliente_chat(alias);
            cliente.setBounds(0,0,440,170);
            cliente.setVisible(true);
            new Thread(cliente).start();

        }
        else{
            System.out.println("No se ha introducido alias...");
        }

    }

    //Aqui indicamos las acciones de los botones
    @Override
    public void actionPerformed(ActionEvent ev) {

        //Se acciona el boton salir del chat
        if (ev.getSource() == salir){
            String txt = "\n *** El usuario " + nombre + " abandona el chat..." + " ***";

            try{
                //Se notifica la desconexión
                DatagramPacket salida2 = new DatagramPacket(txt.getBytes(),txt.length(),grupo,puerto);
                multisocketcliente.send(salida2);
                multisocketcliente.close();
                //Se sale del bucle y se notifica la salida
                repetir = false;
                System.out.println("\nEl usuario " + nombre + " abandona el chat...");
                System.exit(0);


            } catch (IOException e) {
                e.printStackTrace();
            }


        }

    }
    //Se reciben y escriben los mensajes
    @Override
    public void run() {
        while (repetir) {
            try {
                //Creamos la entrada de paquetes
                DatagramPacket entrada = new DatagramPacket(buffer, buffer.length);
                multisocketcliente.receive(entrada);
                //La escribimos
                String mostrar = new String(entrada.getData(), 0, entrada.getLength());
                textarea_chat.append( "\n" + mostrar );
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}

