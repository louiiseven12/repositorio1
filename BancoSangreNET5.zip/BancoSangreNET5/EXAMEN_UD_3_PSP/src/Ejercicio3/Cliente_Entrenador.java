package Ejercicio3;

import java.io.DataOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.net.Socket;
import java.util.Scanner;

public class Cliente_Entrenador {


    public static void main(String[] args) throws IOException, ClassNotFoundException {
        //Se crea el socket
        Socket cliente = new Socket("localhost", 6000);
        //Creo el scanner para pedir datos
        Scanner scanner = new Scanner(System.in);

        //Creo el flujo de entrada y salida
        DataOutputStream flujoSalida;
        ObjectInputStream flujoEntrada = null;

        //el pokemon introducido
        String pokemonGo = null;

        //Creo el objeto Pokemon
        Pokemon pokemonFueraDeLaPokeball = new Pokemon();
        //Bucle de ejecución
        do {
            //Pido el ID del pokemon
            System.out.println("ID Del Pokemon: ");
            pokemonGo = scanner.nextLine();

            //Inicializo el flujo de salida
            flujoSalida = new DataOutputStream(cliente.getOutputStream());
            flujoSalida.writeUTF(pokemonGo);
            //Confirmo el envío
            System.out.println("\t\tID Enviado");

            if (!pokemonGo.equals("*")) {
                //Obtengo los datos y muestro
                flujoEntrada = new ObjectInputStream(cliente.getInputStream());
                pokemonFueraDeLaPokeball = (Pokemon) flujoEntrada.readObject();
                System.out.println("Pokemon: " + pokemonFueraDeLaPokeball.getNombre() + "\nElemento: " + pokemonFueraDeLaPokeball.getElemento());

                for(Golpe elemento : pokemonFueraDeLaPokeball.getAttack()) {
                    System.out.println("\tAtaque: " + elemento.getAtaque() + " - Daño: " + elemento.getDaño());
                }
            }


        } while (!pokemonGo.equals("*"));

        //Cierro los sockets y las conexiones de entrada y salida
        flujoSalida.close();
        flujoEntrada.close();
        scanner.close();
        cliente.close();

    }
}

