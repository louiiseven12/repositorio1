package Ejercicio3;

import java.io.*;
import java.net.Socket;

public class Hilos extends Thread {

    //Listado de Golpes
    Golpe ataque1 = new Golpe("Hojas Afiladas", 45);
    Golpe ataque2 = new Golpe("Aliento Dragon", 50);
    Golpe ataque3 = new Golpe("Pistola Agua", 30);
    Golpe ataque4 = new Golpe("Ataque Rápido", 10);
    Golpe listaAta1[] = {ataque1,ataque4};
    Golpe listaAta2[] = {ataque2,ataque4};
    Golpe listaAta3[] = {ataque3,ataque4};

    //Lista de debilidades
    Tipo_Elemento tipElem1 = new Tipo_Elemento("Agua", "Planta");
    Tipo_Elemento tipElem2 = new Tipo_Elemento("Planta", "Fuego");
    Tipo_Elemento tipElem3 = new Tipo_Elemento("Fuego", "Agua");

    //Lista de pokemon, tipo y ataques
    Pokemon pokeball_1 = new Pokemon(1, "Topterra", tipElem2, listaAta1);
    Pokemon pokeball_2 = new Pokemon(2, "Charizard", tipElem3, listaAta2);
    Pokemon pokeball_3 = new Pokemon(3, "Blastoise", tipElem1, listaAta3);
    Pokemon lista_Pokeballs[] = {pokeball_1, pokeball_2, pokeball_3};

    Socket ClienteConectado = null;
    int numClienteConectado;
    //Creo el flujo de entrada y salida
    DataInputStream flujoEntrada;
    ObjectOutputStream flujoSalida;


    public Hilos(Socket clienteconectado, int numclienteconectado) {
        this.ClienteConectado = clienteconectado;
        this.numClienteConectado = numclienteconectado;
    }

    public void run() {

        int ID = 0;
        String ID_PKM = "";

        System.out.println("Cliente " + numClienteConectado + " conectado.");

        Pokemon pokemon = new Pokemon();

        while (!ID_PKM.equals("*")) {

            try {

                flujoEntrada = new DataInputStream(ClienteConectado.getInputStream());
                ID_PKM = flujoEntrada.readUTF();

            } catch (IOException e) {
                e.printStackTrace();
            }

            if (!ID_PKM.equals("*")) {

                ID = Integer.parseInt(ID_PKM);
                System.out.println("Consultando Pokemon....: " + ID + ", solicitado por el cliente: " + numClienteConectado);

                for (Pokemon element : lista_Pokeballs) {

                    if (element.getNumeroPokedex() == ID) {

                        pokemon = element;

                        System.out.println(pokemon.getNombre());

                    }
                }

                try{
                    flujoSalida = new ObjectOutputStream(ClienteConectado.getOutputStream())
                    ;
                    flujoSalida.writeObject(pokemon);

                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }
}

