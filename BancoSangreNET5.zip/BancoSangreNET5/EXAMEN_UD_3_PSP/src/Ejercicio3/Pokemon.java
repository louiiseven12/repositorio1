package Ejercicio3;


import java.io.Serializable;

public class Pokemon  implements Serializable {

    int numeroPokedex;
    String nombre;
    Tipo_Elemento elemento;
    Golpe[] attack;

    //Constructor vacío
    public Pokemon(){
        numeroPokedex = 0;
        nombre = "";
        elemento = new Tipo_Elemento();
        attack = new Golpe[0];
    }
    //Constructor de la clase
    public Pokemon(int numeroPokedex, String nombre, Tipo_Elemento elemento, Golpe[] attack) {
        this.numeroPokedex = numeroPokedex;
        this.nombre = nombre;
        this.elemento = elemento;
        this.attack = attack;
    }
    //Metodo toString para mostrar los datos de los pokemones
    @Override
    public String toString() {

        return "\n Pokemon{" +
                "numeroPokedex=" + numeroPokedex +
                ", nombre='" + nombre + '\'' +
                ", elemento=" + elemento +
                ", ataque=" + attack +
                '}';
    }


    //Getter  Setter
    public int getNumeroPokedex() {
        return numeroPokedex;
    }

    public void setNumeroPokedex(int numeroPokedex) {
        this.numeroPokedex = numeroPokedex;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public Tipo_Elemento getElemento() {
        return elemento;
    }

    public void setElemento(Tipo_Elemento elemento) {
        this.elemento = elemento;
    }

    public Golpe[] getAttack() {

        return attack;
    }

    public void setAttack(Golpe[] attack) {
        this.attack = attack;
    }
}

