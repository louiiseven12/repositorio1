package Ejercicio2;


import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class Servidor_Hilos {
    public static void main(String[] args) throws IOException {
        //Creo el socket y muestro un mensaje de que está inicializado
        ServerSocket servidor = new ServerSocket(44444);
        System.out.println("Servidor_Hilos iniciado...");

        //Bucle de conexion
        while (true) {
            //Inicio el socket y acepto al cliente
            Socket cliente = new Socket();
            cliente = servidor.accept();
            //Creo el hilo y lo inicio
            Hilos hilo = new Hilos(cliente);
            hilo.start();
        }
    }
}

