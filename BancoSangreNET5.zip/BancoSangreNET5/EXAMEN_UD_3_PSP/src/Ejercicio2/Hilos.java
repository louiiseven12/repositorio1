package Ejercicio2;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;

public class Hilos extends Thread {


    BufferedReader entradaBuffer;
    PrintWriter salidaBuffer;
    Socket socketHilo;

    //Creo el socket y inicializo el buffer de lectura y escritura
    public Hilos(Socket socket) throws IOException {
        this.socketHilo = socket;
        salidaBuffer = new PrintWriter(socket.getOutputStream(), true);
        entradaBuffer = new BufferedReader(new InputStreamReader(socket.getInputStream()));
    }

    public void run() {
        //Imprime la entrada del cliente
        String msg = "";
        System.out.println("=>  Conecta IP /" + socketHilo.getInetAddress() + ", Puerto remoto: " + socketHilo.getPort());

        //Si no recibe un "*" lee el buffer y lo imprime
        while (!msg.trim().equals("*")) {
            try {
                msg = entradaBuffer.readLine();
            } catch (IOException e) {
                e.printStackTrace();
            }
            if(!msg.trim().equals("*")) {
                salidaBuffer.println(msg.trim().toUpperCase());
            }
        }
        //Imprime la salida del cliente
        System.out.println("\t=>Desconecta IP /" + socketHilo.getInetAddress() + ", Puerto remoto: " + socketHilo.getPort()+"\n");
        salidaBuffer.close();

        //Cierra el buffer
        try {
            entradaBuffer.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        //Cierra el hilo
        try {
            socketHilo.close();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}

