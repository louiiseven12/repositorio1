package Ejercicio2;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.net.Socket;

public class Cliente_Hilos {

    public static void main(String[] args) throws IOException {

        //Creo el socket
        String host = "localhost";
        int puerto = 44444;
        Socket cliente = new Socket(host, puerto);

        //Creo el flujo de salida
        PrintWriter salida = new PrintWriter(cliente.getOutputStream(), true);
        //Creo el flujo de entrada
        BufferedReader entrada = new BufferedReader(new InputStreamReader(cliente.getInputStream()));

        //Creo la interfaz
        JFrame frame = new JFrame("Cliente_Hilos Hilo");
        frame.setLayout(new FlowLayout());
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        //Creo el campo en el que introduzco los datos
        JTextField txt_min = new JTextField();
        txt_min.setPreferredSize(new Dimension(200, 30));

        //Creo el campo que muestra el resultado
        JTextField txt_mayus = new JTextField();
        txt_mayus.setEditable(false);
        txt_mayus.setPreferredSize(new Dimension(200, 30));

        //Le indico el orden de los elementos
        frame.add(txt_min, BorderLayout.NORTH);
        frame.add(txt_mayus, BorderLayout.CENTER);

        //Creo el panel sobre el que pongo los botones
        JPanel panel = new JPanel();

        //Creo los botones
        JButton btn_enviar, btn_limpiar, btn_salir;
        btn_enviar = new JButton("Enviar");
        btn_limpiar = new JButton("Limpiar");
        btn_salir = new JButton("Salir");

        //Le añado funcionalidades
        ActionListener btn_accion = e -> {

            //Se activa cuando se pulsa enviar
            if(e.getSource() == btn_enviar) {
                String cadenaEnviada = txt_min.getText();
                salida.println(cadenaEnviada);
                if (!cadenaEnviada.trim().equals("*")) {
                    try {
                        String cadenaRecibida = entrada.readLine();
                        txt_mayus.setText(cadenaRecibida);
                    } catch (IOException ioException) {
                        ioException.printStackTrace();
                    }
                }
            }
            //Se activa cuando se pulsa limpiar
            if(e.getSource() == btn_limpiar) {
                txt_min.setText("");
                txt_mayus.setText("");
            }
            //Se activa cuando se pulsa salir
            if(e.getSource() == btn_salir) {
                String cadenaEnviada = "*";
                salida.println(cadenaEnviada);
                salida.close();
                try {
                    entrada.close();
                    cliente.close();
                } catch (IOException ioException) {
                    ioException.printStackTrace();
                }
                System.exit(0);
            }

        };
        //Añado los botones
        panel.add(btn_enviar, BorderLayout.EAST);
        panel.add(btn_limpiar, BorderLayout.SOUTH);
        panel.add(btn_salir, BorderLayout.EAST);

        //Le indico la funcionalidad de los botones
        btn_enviar.addActionListener(btn_accion);
        btn_limpiar.addActionListener(btn_accion);
        btn_salir.addActionListener(btn_accion);

        //Mostramos la ventana
        frame.add(panel);
        frame.setSize(300, 150);
        frame.setResizable(false);
        frame.setVisible(true);
        frame.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);

    }

}

