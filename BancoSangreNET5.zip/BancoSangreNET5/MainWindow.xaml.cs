﻿using System.Windows;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Diagnostics;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using MySqlConnector;
using BancoSangre.Modelo;
using System.Collections;

namespace BancoSangreNET5
{
    
    public partial class MainWindow : Window
    {
        string connectionString =
                "datasource = localhost;" +
                "port = 3306;" +
                "username = root;" +
                "password = ;" +
                "database = deint;";


        public MainWindow()
        {
            InitializeComponent();
            btnModificar.IsEnabled = false;
        }

        
        private void btnInsertar_Click(object sender, RoutedEventArgs e)
        {

            if (string.IsNullOrEmpty(txtDNI.Text.Trim()) 
                || string.IsNullOrEmpty(txtNombre.Text.Trim()) 
                || string.IsNullOrEmpty(txtCP.Text.Trim())
                || string.IsNullOrEmpty(txtDireccion.Text.Trim())
                || string.IsNullOrEmpty(txtEMAIL.Text.Trim())
                || string.IsNullOrEmpty(txtFecha.Text.Trim())
                || string.IsNullOrEmpty(txtLocalidad.Text.Trim())
                || string.IsNullOrEmpty(txtTelefono.Text.Trim()))
            {
                MessageBox.Show("Por favor, introduce todos los campos", "Datos MySQL",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            MySqlConnection conn = new MySqlConnection(connectionString);
            conn.Open();
            MySqlCommand comm = conn.CreateCommand();
            comm.CommandText = "INSERT INTO donante(dni,nombre,direc,cp,localidad,telef,fecnac,correo,grupsang,factrh) " +
                "VALUES(?dni,?nombre,?direc,?cp,?localidad,?telef,?fecnac,?correo,?grupsang,?factrh)";
            // Decimos que los valores son los de los campos
            comm.Parameters.AddWithValue("?dni", txtDNI.Text);
            comm.Parameters.AddWithValue("?nombre", txtNombre.Text);
            comm.Parameters.AddWithValue("?direc", txtDireccion.Text);
            comm.Parameters.AddWithValue("?cp", txtCP.Text);
            comm.Parameters.AddWithValue("?localidad", txtLocalidad.Text);
            comm.Parameters.AddWithValue("?telef", txtTelefono.Text);
            comm.Parameters.AddWithValue("?fecnac", txtFecha.Text);
            comm.Parameters.AddWithValue("?correo", txtEMAIL.Text);
            comm.Parameters.AddWithValue("?grupsang", grupoSang.Text);
            comm.Parameters.AddWithValue("?factrh", factorRH.Text);
          
            // Ejecutamos, cerramos la onexion y volvemos a llamar al metodo gridFill, para luego mostrar un mensaje
            // de que todo esta correcto
            comm.ExecuteNonQuery();
            conn.Close();
            MessageBox.Show("Datos guardados", "Datos MySQL",
                    MessageBoxButton.OK, MessageBoxImage.Information);

            txtDNI.Clear();
            txtNombre.Clear();
            txtDireccion.Clear();
            txtFecha.Clear();
            txtLocalidad.Clear();
            txtTelefono.Clear();
            txtCP.Clear();
            txtEMAIL.Clear();

            conexion();
        }

        private void btnConsultarTodo_Click(object sender, RoutedEventArgs e)
        {
            //Tratamiento de los datos que obtenemos y los colocamos en su lugar dentro de MainWindow.xaml
            using (MySqlConnection con = new MySqlConnection(connectionString))
            {
                using (MySqlCommand cmd = new MySqlCommand("SELECT * FROM donante", con))
                {
                    cmd.CommandType = CommandType.Text;
                    Trace.WriteLine(cmd);
                    using (MySqlDataAdapter sda = new MySqlDataAdapter(cmd))
                    {
                        using (DataTable dt = new DataTable())
                        {
                            sda.Fill(dt);

                            tablaDonante.ItemsSource = dt.DefaultView;

                        }

                    }
                }
            }


        }

        private void conexion() {
            //Tratamiento de los datos que obtenemos y los colocamos en su lugar dentro de MainWindow.xaml
            using (MySqlConnection con = new MySqlConnection(connectionString))
            {
                using (MySqlCommand cmd = new MySqlCommand("SELECT * FROM donante", con))
                {
                    cmd.CommandType = CommandType.Text;
                    Trace.WriteLine(cmd);
                    using (MySqlDataAdapter sda = new MySqlDataAdapter(cmd))
                    {
                        using (DataTable dt = new DataTable())
                        {
                            sda.Fill(dt);
                            tablaDonante.ItemsSource = dt.DefaultView;
                        }
                    }
                }
            }
        }

        private void btnConsultarDNI_Click(object sender, RoutedEventArgs e)
        {
            using (MySqlConnection con = new MySqlConnection(connectionString))
            {
                

                if (string.IsNullOrEmpty(txtDNI.Text.Trim()))
                {
                    MessageBox.Show("Por favor, introduce un DNI", "Datos MySQL",
                        MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }
                using (MySqlCommand cmd = new MySqlCommand("SELECT * FROM donante WHERE dni = ?dni", con))
                {
                    cmd.Parameters.AddWithValue("?dni", txtDNI.Text);
                    cmd.CommandType = CommandType.Text;
                    Trace.WriteLine(cmd);
                    using (MySqlDataAdapter sda = new MySqlDataAdapter(cmd))
                    {
                        using (DataTable dt = new DataTable())
                        {
                            sda.Fill(dt);
                            tablaDonante.ItemsSource = dt.DefaultView;
                        }
                    }
                }
            }
        }

        private void btnEliminar_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                
                // El metodo eliminar es exactamente igual que los otros dos
                //int id = tablaDonante.SelectedIndex;
                MySqlConnection conn = new MySqlConnection(connectionString);
                conn.Open();
                object v = ((DataRowView)tablaDonante.SelectedValue)["dni"];
                string dni = (string)v;
                MySqlCommand command = new MySqlCommand("DELETE FROM donante WHERE dni ='" + dni + "';", conn);
                command.ExecuteNonQuery();
                MessageBox.Show("Eliminado correctamente.");
                conn.Close();
                conexion();
            }
            // Si hay una excepcion, que se lance un mensaje de fallo
            catch (Exception ex)
            {
                MessageBox.Show("ERROR " + ex.Message, "Fallo an el CRUD", MessageBoxButton.OK, MessageBoxImage.Error);
            }
          
        }

        private void btnModificar_Click(object sender, RoutedEventArgs e)
        {
            
            MySqlConnection conn = new MySqlConnection(connectionString);
            conn.Open();
            object a = ((DataRowView)tablaDonante.SelectedValue)["dni"];
            object b = ((DataRowView)tablaDonante.SelectedValue)["nombre"];
            object c = ((DataRowView)tablaDonante.SelectedValue)["direc"];
            object d = ((DataRowView)tablaDonante.SelectedValue)["cp"];
            object l = ((DataRowView)tablaDonante.SelectedValue)["localidad"];
            object f = ((DataRowView)tablaDonante.SelectedValue)["telef"];
            object g = ((DataRowView)tablaDonante.SelectedValue)["fecnac"];
            object h = ((DataRowView)tablaDonante.SelectedValue)["correo"];
            object i = ((DataRowView)tablaDonante.SelectedValue)["grupsang"];
            object j = ((DataRowView)tablaDonante.SelectedValue)["factrh"];
            
            string dni = (string)a;
            string nombre = (string)b;
            string direc = (string)c;
            int cp = (int)d;
            string localidad = (string)l;
            int telef = (int)f;
            string fecnac = (string)g;
            string correo = (string)h;
            string grupsang = (string)i;
            string factrh = (string)j;

            if (string.IsNullOrEmpty(txtDNI.Text.Trim()))
            {
                txtDNI.Text = dni;
                txtDNI.IsEnabled = false;
                txtNombre.Text = nombre;
                txtDireccion.Text = direc;
                txtCP.Text = Convert.ToString(cp);
                txtLocalidad.Text = localidad;
                txtTelefono.Text = Convert.ToString(telef);
                txtFecha.Text = fecnac;
                txtEMAIL.Text = correo;

                if (grupsang.Equals("A"))
                {
                    grupoSang.SelectedIndex = 0;
                }
                else if (grupsang.Equals("B"))
                {
                    grupoSang.SelectedIndex = 1;
                }
                else if (grupsang.Equals("AB"))
                {
                    grupoSang.SelectedIndex = 2;
                }
                else if (grupsang.Equals("0"))
                {
                    grupoSang.SelectedIndex = 3;
                }

                if (factrh.Equals("+"))
                {
                    factorRH.SelectedIndex = 0;
                }
                else
                {
                    factorRH.SelectedIndex = 1;
                }

            }
            else
            {
                

                MySqlCommand comm= new MySqlCommand("UPDATE donante SET nombre =?nombre ,direc=?direc,cp=?cp,localidad=?localidad,telef=?telef,fecnac=?fecnac" +
                    ",correo=?correo,grupsang=?grupsang,factrh=?factrh " +
                    " WHERE dni =?dni", conn);
                // Decimos que los valores son los de los campos

                comm.Parameters.AddWithValue("?dni", txtDNI.Text);
                comm.Parameters.AddWithValue("?nombre", txtNombre.Text);
                comm.Parameters.AddWithValue("?direc", txtDireccion.Text);
                comm.Parameters.AddWithValue("?cp", txtCP.Text);
                comm.Parameters.AddWithValue("?localidad", txtLocalidad.Text);
                comm.Parameters.AddWithValue("?telef", txtTelefono.Text);
                comm.Parameters.AddWithValue("?fecnac", txtFecha.Text);
                comm.Parameters.AddWithValue("?correo", txtEMAIL.Text);
                comm.Parameters.AddWithValue("?grupsang", grupoSang.Text);
                comm.Parameters.AddWithValue("?factrh", factorRH.Text);

                comm.ExecuteNonQuery();

                conn.Close();

                txtDNI.Clear();
                txtNombre.Clear();
                txtDireccion.Clear();
                txtCP.Clear();
                txtLocalidad.Clear();
                txtTelefono.Clear();
                txtFecha.Clear();
                txtEMAIL.Clear();

                MessageBox.Show("Registro modificado correctamente.");
                txtDNI.IsEnabled = true;
                btnModificar.IsEnabled = false;
                conexion();


            }
            
        
        }

        private void btnConsultaDonacion_Click(object sender, RoutedEventArgs e)
        {

            string codSanitario = "";
            string fecha = "";
            string cant = "";
            string incidencia = "";
            string nomSanitario;

            if (string.IsNullOrEmpty(tbDniDonacion.Text.Trim()))
            {
                MessageBox.Show("Introduzca un DNI de donante");
            }
            else
            {
                MySqlConnection conn = new MySqlConnection(connectionString);

                MySqlCommand command = new MySqlCommand("SELECT nombre, grupsang, factrh FROM donante WHERE dni = ?dni;", conn);
                MySqlCommand command2 = new MySqlCommand("SELECT fechaDonacion, cantidad, incidencia, codSanitario " +
                    " FROM donaciones WHERE dniDonante = ?dni;", conn);

                command.Parameters.AddWithValue("?dni", tbDniDonacion.Text);
                command2.Parameters.AddWithValue("?dni", tbDniDonacion.Text);

                command.CommandType = CommandType.Text;
                command2.CommandType = CommandType.Text;

                MySqlDataReader reader;
                MySqlDataReader reader2;

                conn.Open();

                reader = command.ExecuteReader();
                
                

                //Si el reader no está vacío entra en el bucle para la lectura
                if (reader.HasRows)
                {
                    //Bucle para leer
                    while (reader.Read())
                    {

                        //Tratamiento de los datos que obtenemos y los colocamos en su lugar dentro de MainWindow.xaml
                        string[] row = { reader.GetString(0), reader.GetString(1), reader.GetString(2) };

                        labelNomDonanción.Content = row[0];
                        labelSangreDonacion.Content = row[1] + row[2];
                    }
                }
                else
                {
                    //Esto se ejecuta si no se encuentran datos
                    Console.WriteLine("No se encontraron datos.");
                    
                }
                conn.Close();

                conn.Open();
                reader2 = command2.ExecuteReader();

                if (reader2.HasRows)
                {
                    //Bucle para leer
                    while (reader2.Read())
                    {

                        //Tratamiento de los datos que obtenemos y los colocamos en su lugar dentro de MainWindow.xaml
                        string[] row2 = { reader2.GetString(0), reader2.GetString(1), reader2.GetString(2), reader2.GetString(3) };

                        fecha = row2[0];
                        cant = row2[1];
                        incidencia = row2[2];
                        codSanitario = row2[3];


                    }
                }
                else
                {
                    //Esto se ejecuta si no se encuentran datos
                    Console.WriteLine("No se encontraron datos.");

                }

                
                conn.Close();

                conn.Open();
                MySqlCommand command3 = new MySqlCommand("SELECT nomSanitario " +
                   " FROM sanitario WHERE codSanitario ='" + codSanitario + "';", conn);
                MySqlDataReader reader3 = command3.ExecuteReader();

                if (reader3.HasRows)
                {
                    //Bucle para leer
                    while (reader3.Read())
                    {

                        //Tratamiento de los datos que obtenemos y los colocamos en su lugar dentro de MainWindow.xaml
                        string[] row = { reader3.GetString(0) };

                        nomSanitario = row[0];
                        var datosTabla = new Modelo.TablaDonaciones(codSanitario, nomSanitario, fecha, cant, incidencia);
                        TablaDonacion.Items.Add(datosTabla);

                    }
                }
                else
                {
                    //Esto se ejecuta si no se encuentran datos
                    Console.WriteLine("No se encontraron datos.");

                }


                

                
   
                conn.Close();
            }
        }

        private void tablaDonante_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            if (tablaDonante.SelectedItem != null)
            {
                btnModificar.IsEnabled = true;
            }
            else
            {
                btnModificar.IsEnabled = false;
            }
        }

        private void btnBuscar_Click(object sender, RoutedEventArgs e)
        {
            string grupsang = cbGrupSang.Text;
            string factrh = cbFactorRH.Text;
            string donaA;
            string recibeDe;

            tablaCompatibilidad.Items.Clear();

            if (grupsang.Equals("A"))
            {
                if (factrh.Equals("+"))
                {
                    var datosTablaComp = new Modelo.Compatible("A+, AB+", "A+, A-, O+, O-");
                    tablaCompatibilidad.Items.Add(datosTablaComp);
                }
                else
                {
                    var datosTablaComp = new Modelo.Compatible("A+, A-, AB+, AB-", "A-, O-");
                    tablaCompatibilidad.Items.Add(datosTablaComp);
                }
            }else if (grupsang.Equals("0"))
            {
                if (factrh.Equals("+"))
                {
                    var datosTablaComp = new Modelo.Compatible("O+, A+, B+, AB+", "O+, O-");
                    tablaCompatibilidad.Items.Add(datosTablaComp);
                }
                else
                {
                    var datosTablaComp = new Modelo.Compatible("TODOS", "O-");
                    tablaCompatibilidad.Items.Add(datosTablaComp);
                }
            }
            else if (grupsang.Equals("AB"))
            {
                if (factrh.Equals("+"))
                {
                    var datosTablaComp = new Modelo.Compatible("AB+", "TODOS");
                    tablaCompatibilidad.Items.Add(datosTablaComp);
                }
                else
                {
                    var datosTablaComp = new Modelo.Compatible("AB+, AB-", "AB-, A-, B-, O-");
                    tablaCompatibilidad.Items.Add(datosTablaComp);
                }
            }
            else if (grupsang.Equals("B"))
            {
                if (factrh.Equals("+"))
                {
                    var datosTablaComp = new Modelo.Compatible("B+, AB+", "B+, B-, O+, O-");
                    tablaCompatibilidad.Items.Add(datosTablaComp);
                }
                else
                {
                    var datosTablaComp = new Modelo.Compatible("B+, B-, AB+, AB-", "B-, O-");
                    tablaCompatibilidad.Items.Add(datosTablaComp);
                }
            }



        }
    }
}
