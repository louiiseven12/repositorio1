-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 23-02-2022 a las 13:35:04
-- Versión del servidor: 10.4.21-MariaDB
-- Versión de PHP: 8.0.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `deint`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `donante`
--

CREATE TABLE `donante` (
  `dni` varchar(9) NOT NULL,
  `nombre` varchar(50) NOT NULL,
  `direc` varchar(50) NOT NULL,
  `cp` int(5) NOT NULL,
  `localidad` varchar(40) NOT NULL,
  `telef` int(9) NOT NULL,
  `fecnac` varchar(10) NOT NULL,
  `correo` varchar(50) NOT NULL,
  `grupsang` varchar(50) NOT NULL,
  `factrh` varchar(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `donante`
--

INSERT INTO `donante` (`dni`, `nombre`, `direc`, `cp`, `localidad`, `telef`, `fecnac`, `correo`, `grupsang`, `factrh`) VALUES
('23165498L', 'David', 'Calle girasol', 74123, 'Sevilla', 951487623, '22-12-2010', 'saasas', 'B', '-'),
('29503251R', 'Luismi ', 'Calle Cacahuete', 41300, 'La Rinconada', 615407542, '02-07-1996', 'lduranotero@safareyes.es', '0', '+');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `donante`
--
ALTER TABLE `donante`
  ADD PRIMARY KEY (`dni`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
