-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 23-02-2022 a las 13:35:12
-- Versión del servidor: 10.4.21-MariaDB
-- Versión de PHP: 8.0.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `deint`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `sanitario`
--

CREATE TABLE `sanitario` (
  `codSanitario` varchar(9) NOT NULL,
  `nomSanitario` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `sanitario`
--

INSERT INTO `sanitario` (`codSanitario`, `nomSanitario`) VALUES
('26359814T', 'Noelia Gonzalez'),
('95487562Ñ', 'Joaquin Fuentes'),
('96385274M', 'Mariano Rosales'),
('98653214B', 'Alejandro Mejías');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `sanitario`
--
ALTER TABLE `sanitario`
  ADD PRIMARY KEY (`codSanitario`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
