﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BancoSangre.Modelo
{
    public class Donantes
    {
        private string dni;
        private string nombre;
        private string direc;
        private string codigoPostal;
        private string localidad;
        private string telefono;
        private string fechaNacimiento;
        private string Email;
        private string grupoSanguineo;
        private string factorRH;
        public Donantes(string dni, string nombre, string direc, string codigoPostal, string localidad, string fechaNacimiento, string Email, string telefono, string grupoSanguineo, string factorRH)
        {
            this.dni = dni;
            this.nombre = nombre;
            this.direc = direc;
            this.codigoPostal = codigoPostal;
            this.localidad = localidad;
            this.telefono = telefono;
            this.fechaNacimiento = fechaNacimiento;
            this.Email = Email;
            this.grupoSanguineo = grupoSanguineo;
            this.factorRH = factorRH;
        }

        public Donantes()
        {

        }

        public string Dni { get => dni; set => dni = value; }
        public string Nombre { get => nombre; set => nombre = value; }
        public string Direc { get => direc; set => direc = value; }
        public string Cp { get => codigoPostal; set => codigoPostal = value; }
        public string Local { get => localidad; set => localidad = value; }
        public string telf { get => telefono; set => telefono = value; }
        public string Fecnac{ get => fechaNacimiento; set => fechaNacimiento = value; }
        public string Mail { get => Email; set => Email = value; }
        public string GrupSang { get => grupoSanguineo; set => grupoSanguineo = value; }
        public string FactorRH { get => factorRH; set => factorRH = value; }



    }
}
