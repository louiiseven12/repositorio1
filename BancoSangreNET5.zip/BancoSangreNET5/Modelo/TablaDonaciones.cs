﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BancoSangreNET5.Modelo
{
    class TablaDonaciones
    {
        private string codSanitario;
        private string nomSanitario;
        private string fecha;
        private string cant;
        private string incidencia;

        public TablaDonaciones(string codSanitario, string nomSanitario, string fecha, string cant, string incidencia)
        {
            this.codSanitario = codSanitario;
            this.nomSanitario = nomSanitario;
            this.fecha = fecha;
            this.cant = cant;
            this.incidencia = incidencia;
            
        }

        public string CodSanitario { get => codSanitario; set => codSanitario = value; }
        public string NomSanitario { get => nomSanitario; set => nomSanitario = value; }
        public string Fecha { get => fecha; set => fecha = value; }
        public string Cant { get => cant; set => cant = value; }
        public string Incidencia { get => incidencia; set => incidencia = value; }
    }
}
