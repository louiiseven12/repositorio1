﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BancoSangreNET5.Modelo
{
    class Compatible
    {
        private string donaA;
        private string recibeDe;
       

        public Compatible(string dona, string recibe)
        {
            this.donaA = dona;
            this.recibeDe = recibe;
        }

        public string DonaA { get => donaA; set => donaA = value; }
        public string RecibeDe { get => recibeDe; set => recibeDe = value; }
    }

    
}
